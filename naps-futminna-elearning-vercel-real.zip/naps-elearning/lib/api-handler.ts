import { NextResponse } from "next/server";

/**
 * Wraps a route handler so an unexpected error becomes a clean JSON response
 * (instead of an empty 500 that the browser can't parse, which used to show
 * as "Could not reach the server"). Full details go to the Vercel logs.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function safe<T extends (...args: any[]) => Promise<Response>>(handler: T): T {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return (async (...args: any[]) => {
    try {
      return await handler(...args);
    } catch (err) {
      console.error("API error:", err);
      const e = err as { code?: string; message?: string };
      const msg = e?.message ?? "";

      let error = "Something went wrong on our side. Please try again shortly.";
      if (e?.code === "P2021" || e?.code === "P2022") {
        error = "The database hasn't been set up yet. The administrator needs to run the database setup.";
      } else if (
        e?.code === "P1000" || e?.code === "P1001" || e?.code === "P1002" ||
        e?.code === "P1017" || /Environment variable not found|DATABASE_URL|Can't reach database/i.test(msg)
      ) {
        error = "The server can't reach its database. The administrator needs to check the database settings.";
      } else if (/AUTH_SECRET/.test(msg)) {
        error = "The server is missing a required setting (AUTH_SECRET). The administrator needs to add it in Vercel.";
      }
      return NextResponse.json({ error }, { status: 500 });
    }
  }) as T;
}
