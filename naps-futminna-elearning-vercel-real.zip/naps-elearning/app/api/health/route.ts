import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

/** Setup check: open /api/health after deploying. Shows only yes/no, never secrets. */
export async function GET() {
  const present = (name: string) => Boolean(process.env[name]?.trim());
  const env = {
    DATABASE_URL: present("DATABASE_URL"),
    DIRECT_URL: present("DIRECT_URL"),
    AUTH_SECRET: present("AUTH_SECRET") && (process.env.AUTH_SECRET?.length ?? 0) >= 16,
    EMAIL_SERVER: present("EMAIL_SERVER"),
    EMAIL_FROM: present("EMAIL_FROM"),
    AI_API_KEY: present("AI_API_KEY"),
    BLOB_READ_WRITE_TOKEN: present("BLOB_READ_WRITE_TOKEN"),
  };

  let database: "ok" | "tables_missing" | "unreachable" = "ok";
  try {
    await prisma.user.count();
  } catch (err) {
    const code = (err as { code?: string }).code;
    database = code === "P2021" || code === "P2022" ? "tables_missing" : "unreachable";
  }

  const ready = database === "ok" && env.DATABASE_URL && env.AUTH_SECRET && env.EMAIL_SERVER;
  return NextResponse.json({ ready, database, env }, { status: ready ? 200 : 503 });
}
