import { NextResponse } from "next/server";
import { safe } from "@/lib/api-handler";
import { clearSessionCookie } from "@/lib/session";

async function POST_handler() {
  await clearSessionCookie();
  return NextResponse.json({ success: true });
}

export const POST = safe(POST_handler);
