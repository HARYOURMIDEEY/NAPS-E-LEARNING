// Build script used by `npm run build` (and therefore by Vercel).
//
// Normal builds:  prisma generate -> next build
// First-time setup: add the env var SETUP_DATABASE=true in Vercel and redeploy.
//   It will ALSO create the database tables (prisma db push) and the Super
//   Admin + courses (seed, needs INITIAL_SUPER_ADMIN_PASSWORD). Both are safe
//   to repeat: db push refuses destructive changes and the seed only inserts
//   what's missing. Remove SETUP_DATABASE afterwards.
import { execSync } from "node:child_process";

const run = (cmd) => {
  console.log(`\n> ${cmd}`);
  execSync(cmd, { stdio: "inherit" });
};

run("npx prisma generate");

if (process.env.SETUP_DATABASE === "true") {
  console.log("\nSETUP_DATABASE=true -> setting up the database...");
  run("npx prisma db push --skip-generate");
  if (process.env.INITIAL_SUPER_ADMIN_PASSWORD) {
    run("npx tsx prisma/seed.ts");
  } else {
    console.log("INITIAL_SUPER_ADMIN_PASSWORD not set -> skipping admin/course seed.");
  }
}

run("npx next build");
